<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user_show', 'user_create', 'user_edit', 'user_delete'])): ?>
        <!-- User DataTable -->
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <?php if(request()->has('show_deleted')): ?>
                        <h4 class="mb-0"><?php echo e(__('global.deleted')); ?><?php echo e(__('pages.users.title')); ?></h4>
                    <?php else: ?>
                        <h4 class="mb-0"><?php echo e(__('pages.users.title')); ?></h4>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_delete')): ?>
                        <!-- Conditional link based on whether show_deleted parameter is present in the request -->
                        
                        
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <!-- Display User DataTable -->
                <?php echo e($dataTable->table()); ?>

            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- Push DataTable scripts -->
    <?php echo $dataTable->scripts(); ?>


    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_delete')): ?>
        <?php echo $__env->make('components.sweetAlert2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['pageName' => config('pages.users.index')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/resources/views/pages/users/index.blade.php ENDPATH**/ ?>