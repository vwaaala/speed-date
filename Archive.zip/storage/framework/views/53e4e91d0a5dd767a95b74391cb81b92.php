<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.png')); ?>">

    <title><?php echo e(config('app.name', 'Larabone')); ?></title>

    <!-- vite styles -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss']); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- page specific styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
<!-- page loader -->
<div id="loader-wrapper">
    <div id="loader" class="page-loader">
        <span class="loader"></span>
    </div>
</div>

<!-- app wrapper -->
<div id="app">

    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->id == 1): ?>
            <!-- sidebar -->
            <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
    <div class="content <?php echo e(auth()->check() ? 'logged-in' : ''); ?>">
        <!-- navbar -->
        <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="p-2 mt-2">
            
            <?php if(session('success')): ?>
                <!-- session message: success -->
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <!-- session message: error -->
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <!-- app::dynamic content-->
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- footer -->
        <footer class="bg-light text-center">
            <p>&copy; 2024 | All rights reserved</p>
        </footer>
    </div>
</div>
<!-- jquery -->
<script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.js')); ?>"></script>
<!-- vite scripts -->
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
<!-- page specific js -->
<?php echo $__env->yieldPushContent('scripts'); ?>
<style>
    .nav-item.active .dropdown-toggle::after {
    display: inline-block;
    margin-left: 0.255em;
    vertical-align: 0.255em;
    content: "";
    border-top: 0;
    border-right: 0.3em solid transparent;
    border-bottom: 0.3em solid;
    border-left: 0.3em solid transparent;
}
</style>
</body>

</html>
<?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/resources/views/layouts/app.blade.php ENDPATH**/ ?>