<?php use Bunker\LaravelSpeedDate\Enums\RatingEnum;use Bunker\LaravelSpeedDate\Models\RatingEvent; ?>

<?php $__env->startPush('styles'); ?>
    <style>

    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Event Details</h4>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_event_create')): ?>
                    <button type="button" class="btn btn-success btn-sm"
                            onclick="openUploadModal('<?php echo e($event->id); ?>')">
                        <i class="bi bi-arrow-up"></i><i class="bi bi-filetype-csv"></i> Participants
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <tbody>
                <tr>
                    <th scope="row">Event Name:</th>
                    <td><?php echo e($event->name); ?></td>
                </tr>
                <tr>
                    <th scope="row">Date and Time:</th>
                    <td><?php echo e($event->happens_on->format('F j, Y h:i A')); ?></td>
                </tr>
                <tr>
                    <th scope="row">Event Type:</th>
                    <td><?php echo e($event->type); ?></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card p-4">
        <div class="row">
            <?php if(auth()->user()->id != 1): ?>
            <div class="col-12">
            <?php else: ?>
            <div class="col-5">
            <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="mb-0">Participants</h4>
                        </div>
                    </div>
                    <div class="card-body table-responsive">
                        <?php if(isset($event->participants) && count($event->participants) > 0): ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>
                                            Name
                                        </th>
                                        <th>
                                            Nick Name
                                        </th>
                                        <?php if(auth()->user()->id == 1): ?>
                                        <th>
                                            Last Name
                                        </th>
                                        <th>
                                            Phone
                                        </th>
                                        <th>
                                            City
                                        </th>
                                        <?php endif; ?>
                                        <th>
                                            Occupation
                                        </th>
                                        <th>
                                            Birthdate
                                        </th>
                                        <th>
                                            Gender
                                        </th>
                                        <th>
                                            Looking For
                                        </th>
                                        <th>
                                            Rating
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $event->matchedParticipants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <?php if($item->id !== auth()->user()->id): ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('users.show', $item->id)); ?>"
                                                   style="text-decoration: underline; color: #007bff; text-decoration-color: #007bff;">
                                                    <div class="d-flex align-items-center">
                                                        <div class="rounded-circle overflow-hidden mr-2"
                                                             style="width: 40px; height: 40px;">
                                                            <img src="<?php echo e(asset($item->avatar)); ?>"
                                                                 alt="<?php echo e($item->name); ?>"
                                                                 class="w-100 h-100">
                                                        </div>
                                                        <span class="ml-2"
                                                              style="margin-left: 8px !important;"><?php echo e($item->name); ?></span>
                                                    </div>
                                                </a>

                                            </td>
                                            <td><?php echo e($item->bio->nickname); ?></td>

                                        <?php if(auth()->user()->id == 1): ?>
                                            <td><?php echo e($item->bio->lastname); ?></td>
                                            <td><?php echo e($item->bio->phone); ?></td>
                                            <td><?php echo e($item->bio->city); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($item->bio->occupation); ?></td>
                                            <td><?php echo e($item->bio->birthdate); ?></td>
                                            <td><?php echo e($item->bio->gender); ?></td>
                                            <td><?php echo e($item->bio->looking_for); ?></td>
                                            <td>
                                                <?php if(auth()->user()->id == 1): ?>
                                                    <?php echo e($event->getEventRatingForUser($event->id)); ?>

                                                <?php else: ?>
                                                <?php echo e(RatingEvent::where([
                                                    ['user_id_from', auth()->user()->id],
                                                    ['user_id_to', $item->id],
                                                    ['event_id', $event->id]
                                                    ])->first()->rating ?? 'No Rating Yet'); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>

                                                <?php if(auth()->user()->hasRole('User')): ?>
                                                    <?php
                                                        $alreadyRated = RatingEvent::where([
                                                            ['user_id_from', auth()->user()->id],
                                                            ['user_id_to', $item->id],
                                                            ['event_id', $event->id]
                                                        ])->exists();
                                                    ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_rating_create')): ?>
                                                        
                                                            <a href="#"
                                                               class="btn btn-sm btn-outline-primary mr-2 rate-button" style="width:100px;"
                                                               onclick="openRateModal('<?php echo e($item->email); ?>', '<?php echo e($event->id); ?>')"><i
                                                                    class="bi bi-activity"></i> Rate Now</a>
                                                        
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_rating_create')): ?>
                                                        <a href="#"
                                                           onclick="confirmDelete('<?php echo e(route('speed_date.events.removeParticipant', ['eventId' => $event->id, 'userId' => $item->id])); ?>', 'POST', {color: 'danger', text: 'Yes, delete it!'})"
                                                           class="btn btn-danger btn-sm"
                                                           title="<?php echo e(__('global.remove')); ?>">
                                                            <i class="bi bi-trash"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            No participants available
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_rating_show')): ?>
                <div class="col-7">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <h4 class="mb-0">Ratings</h4>
                            </div>
                        </div>
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>User From</th>
                                <th>Rating</th>
                                <th>User To</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $event->eventRatings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('users.show', $rating->userFrom->id)); ?>"
                                            style="text-decoration: underline; color: #007bff; text-decoration-color: #007bff;">
                                             <div class="d-flex align-items-center">
                                                 <div class="rounded-circle overflow-hidden mr-2"
                                                      style="width: 40px; height: 40px;">
                                                     <img src="<?php echo e(asset($rating->userFrom->avatar)); ?>"
                                                          alt="<?php echo e($rating->userFrom->name); ?>"
                                                          class="w-100 h-100">
                                                 </div>
                                                 <span class="ml-2"
                                                       style="margin-left: 8px !important;"><?php echo e($rating->userFrom->name); ?></span>
                                             </div>
                                         </a>
                                    </td>
                                    <td><?php echo e($rating->rating); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('users.show', $rating->userTo->id)); ?>"
                                            style="text-decoration: underline; color: #007bff; text-decoration-color: #007bff;">
                                             <div class="d-flex align-items-center">
                                                 <div class="rounded-circle overflow-hidden mr-2"
                                                      style="width: 40px; height: 40px;">
                                                     <img src="<?php echo e(asset($rating->userTo->avatar)); ?>"
                                                          alt="<?php echo e($rating->userTo->name); ?>"
                                                          class="w-100 h-100">
                                                 </div>
                                                 <span class="ml-2"
                                                       style="margin-left: 8px !important;"><?php echo e($rating->userTo->name); ?></span>
                                             </div>
                                         </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_rating_create')): ?>
        <!-- Rating modal -->
        <div class="modal fade" id="rateModal" tabindex="-1" aria-labelledby="rateModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="rateModalLabel">Rate this user</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('speed_date.ratings.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <!-- Hidden field for user email -->
                            <input type="hidden" name="user_email" id="user_email">
                            <input type="hidden" name="event" id="rating_event">
                            <!-- Hidden field for event ID -->
                            <input type="hidden" name="event_id" value="<?php echo e($event->id); ?>">

                            <!-- Radio buttons for rating options -->
                            <?php $__currentLoopData = RatingEnum::toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="rating" id="<?php echo e($rating); ?>"
                                           value="<?php echo e($rating); ?>">
                                    <label class="form-check-label" for="<?php echo e($rating); ?>"><?php echo e(ucfirst($rating)); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Submit Rating</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_event_create')): ?>
        <!-- upload modals -->
        <div class="modal fade" id="modal-file" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Upload csv</h1>
                    </div>
                    <form action="<?php echo e(route('speed_date.events.uploadUsers')); ?>" method="POST"
                          enctype="multipart/form-data">
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="csv_file" class="form-label">Choose CSV File:</label>
                                <input type="file" class="form-control" id="csv_file" name="csv_file" accept=".csv">
                                <input type="hidden" id="event" name="event">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Upload</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_event_delete')): ?>
        <?php echo $__env->make('components.sweetAlert2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <script>
        function openUploadModal(eventId) {
            // Set the event ID in the modal form
            document.getElementById('event').value = eventId;
            // Open the modal
            let csvModal = new bootstrap.Modal(document.getElementById('modal-file'));
            csvModal.show();
        }

        function openRateModal(email, event) {
            // Set the user email in the modal form
            document.getElementById('user_email').value = email;
            document.getElementById('rating_event').value = event;
            // Open the modal
            let rateModal = new bootstrap.Modal(document.getElementById('rateModal'));
            rateModal.show();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/package/laravel-speed-date/src/resources/views/speed-date/events/show.blade.php ENDPATH**/ ?>