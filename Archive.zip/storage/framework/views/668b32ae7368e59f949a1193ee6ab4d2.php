<div class="sidebar d-flex justify-content-between flex-wrap flex-column">
    <ul class="nav flex-column w-100">
        <!-- brand logo -->
        <a href="<?php echo e(route('dashboard')); ?>" class="h3 p-2">
            <img
                src="<?php echo e(asset(config('app.logo'))); ?>" alt="config('app.name', 'LaraBone')"
                class="d-inline-block align-top"
                style="max-height: 35px;">
        </a>
        <?php $__currentLoopData = config('pages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(auth()->user()->can($menuItem['permission'])): ?>
                <?php if(count($menuItem['children']) > 0): ?>
                    <?php
                        $isActive = request()->route()->getName() === $menuItem['href'] || in_array(request()->route()->getName(), array_column($menuItem['children'], 'href'));
                    ?>
                    <li class="nav-item <?php echo e($isActive ? 'active' : ''); ?>">
                        <a href="#"
                           class="nav-link dropdown-toggle collapsed d-flex align-items-center justify-content-between"
                           data-bs-toggle="collapse" data-bs-target="#menu-item-<?php echo e($loop->iteration); ?>"
                           aria-expanded="true">
                            <?php echo e(__($menuItem['name'])); ?>

                        </a>
                        <div class="collapse <?php echo e($isActive ? 'show' : ''); ?>"
                             id="menu-item-<?php echo e($loop->iteration); ?>">
                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                                <?php if(auth()->user()->can($menuItem['permission'])): ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(request()->routeIs($menuItem['href']) ? 'current' : ''); ?>"
                                           href="<?php echo e(route($menuItem['href'])); ?>"><?php echo e(__($menuItem['text'])); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php $__currentLoopData = $menuItem['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->can($childItem['permission']) && $childItem['sidebar'] ): ?>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e(request()->routeIs($childItem['href']) ? 'current' : ''); ?>"
                                               href="<?php echo e(route($childItem['href'])); ?>"><?php echo e(__($childItem['text'])); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </li>
                <?php else: ?>
                    <li class="nav-item <?php echo e(request()->routeIs($menuItem['href']) ? 'active' : ''); ?>">
                        <a class="nav-link"
                           href="<?php echo e(route($menuItem['href'])); ?>"><?php echo e(__($menuItem['name'])); ?></a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

</div>
<?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/resources/views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>