<?php use Bunker\LaravelSpeedDate\Enums\EventTypeEnum; ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/libs/bootstrap-datetimepicker/css/bootstrap-datetimepicker.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_edit')): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><?php echo e(__('global.edit')); ?> <?php echo e(__('speed_date::speed_date.events')); ?></h5>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('speed_date.events.update', $event->id)); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-12 mb-2">
                            <label for="name" class="form-label"><?php echo e(__('global.name')); ?> <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                                   name="name" value="<?php echo e($event->name); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-6 mb-2">
                            <label for="typeSelect" class="form-label"><?php echo e(__('global.type')); ?> <span
                                    class="text-danger">*</span></label>
                            <select class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="typeSelect"
                                    name="type">
                                <?php $__currentLoopData = EventTypeEnum::toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php if($value == $event->type): ?> selected <?php endif; ?>><?php echo e(ucfirst($value)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-6 mb-2">
                            <label for="statusSelect" class="form-label"><?php echo e(__('global.status')); ?> <span
                                    class="text-danger">*</span></label>
                            <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="statusSelect"
                                    name="status">
                                    <option value="1" <?php if($value == $event->status): ?> selected <?php endif; ?>><?php echo e(__('Active')); ?></option>
                                    <option value="0" <?php if($value == $event->status): ?> selected <?php endif; ?>><?php echo e(__('Close')); ?></option>
                            </select>

                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6 mb-2">
                            <label for="happens_on" class="form-label">Happens On</label>
                            <div class="input-group">
                                <input type="text" name="happens_on" value="<?php echo e($event->happens_on->format('d-m-y')); ?>" class="form-control" id="datepicker" required>
                                <div class="input-group-text" data-target="#"
                                     data-toggle="datetimepicker">
                                    <i class="bi bi-calendar"></i>
                                </div>
                                <?php $__errorArgs = ['happens_on'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>

                    <button type="submit" class="btn btn-primary mt-5"><?php echo e(__('global.update')); ?></button>
                </form>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- Initialize datetime picker -->
    <script>
        $(document).ready(function() {
            let currentDate = new Date();
            currentDate.setHours(currentDate.getHours() + 24); // Set the minimum date to 5 hours later

            $('#datepicker').datepicker({
                format: 'dd-mm-yyyy',
                autoclose: true,
                todayHighlight: true,
                startDate: currentDate // Set the minimum date
            });
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/package/laravel-speed-date/src/resources/views/speed-date/events/edit.blade.php ENDPATH**/ ?>