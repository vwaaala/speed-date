<nav class="navbar navbar-expand-md bg-light">
    <div class="container-fluid">
        <?php if(auth()->guard()->guest()): ?>
            <a class="navbar-brand ms-4" href="/">
                <img
                    src="<?php echo e(asset(config('app.logo'))); ?>" alt="config('app.name', 'LaraBone')"
                    class="d-inline-block align-top"
                    style="max-height: 35px;">
            </a>
        <?php else: ?>
            <?php if(auth()->user()->id == 1): ?>
                <a class="btn btn-primary border-0 sidebar-toggle"><i class="bi bi-bar-chart-steps"></i></a>
            <?php endif; ?>
        <?php endif; ?>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 justify-content-end">
                
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('login') ? 'active' : ''); ?>"
                               href="<?php echo e(route('login')); ?>"><?php echo e(__('global.login')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                           aria-expanded="false">
                            <img src="<?php echo e(asset(auth()->user()->avatar)); ?>"
                                 alt="Avatar" class="rounded-circle"
                                 height="30">
                            <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item <?php echo e(request()->routeIs('users.show') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('users.show', auth()->user()->id)); ?>">
                                    <?php echo e(__('global.profile')); ?>

                                </a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <?php echo e(__('global.logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                      class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
            &nbsp;
        </div>
    </div>
</nav>
<?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/resources/views/layouts/partials/navbar.blade.php ENDPATH**/ ?>