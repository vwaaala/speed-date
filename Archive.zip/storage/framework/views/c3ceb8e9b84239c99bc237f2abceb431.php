<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><?php echo e(__('Events')); ?></h4>
                <?php if(isset($events) && count($events) > 0): ?>
                    <form action="#" method="GET" class="form-inline">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control"
                                   placeholder="<?php echo e(__('global.search')); ?>..."
                                   value="<?php echo e($searchQuery ?? ''); ?>">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-success"><i class="bi bi-search"></i></button>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <!-- Table to display permissions -->
            <?php if(isset($events) && count($events) > 0): ?>
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <!-- Column headers -->
                        <th scope="col">Happens on</th>
                        <th scope="col">Name</th>
                        <th scope="col">Participants</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- Loop through permissions and display each permission -->
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- Output the row number -->
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <!-- Display permissions name and description -->
                            <td><?php echo e($value->happens_on->format('l, F j, Y \a\t g:i A')); ?>

                            </td>
                            <td><?php echo e($value->name); ?></td>
                            <td><?php echo e(count($value->participants)); ?></td>
                            <td>
                                <?php if($value->status == 1): ?>
                                    <i class="bi bi-calendar2-check text-primary"></i>
                                <?php else: ?>
                                    <i class="bi bi-calendar-x text-success"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_event_create')): ?>
                                        <button type="button" class="btn btn-primary btn-sm"
                                                onclick="openModal('<?php echo e($value->id); ?>')">
                                            <i class="bi bi-arrow-up"></i><i class="bi bi-filetype-csv"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_event_show')): ?>
                                        <a href="<?php echo e(route('speed_date.events.show', $value->id)); ?>"
                                           class="btn btn-success btn-sm">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_event_delete')): ?>
                                        <a href="<?php echo e(route('speed_date.events.edit', $value->id)); ?>"
                                           class="btn btn-warning btn-sm">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_event_delete')): ?>
                                        <a href="#"
                                           onclick="confirmDelete('<?php echo e(route('speed_date.events.destroy', $value->id)); ?>', 'DELETE', {color: 'danger', text: 'Yes, delete it!'})"
                                           class="btn btn-danger btn-sm"
                                           title="<?php echo e(__('global.delete')); ?>">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <!-- Pagination links -->
                    <tfoot>
                    <tr>
                        <td colspan="3"
                            class="text-center"><?php echo e($events->appends(['search' => $searchQuery])->onEachSide(5)->links()); ?></td>
                    </tr>
                    </tfoot>
                </table>
            <?php else: ?>
                No events available
            <?php endif; ?>
        </div>
    </div>

    <!-- upload modals -->
    <div class="modal fade" id="modal-file" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Upload csv</h1>
                </div>
                <form action="<?php echo e(route('speed_date.events.uploadUsers')); ?>" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="csv_file" class="form-label">Choose CSV File:</label>
                            <input type="file" class="form-control" id="csv_file" name="csv_file" accept=".csv">
                            <input type="hidden" id="event" name="event">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Upload</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sd_event_delete')): ?>
        <?php echo $__env->make('components.sweetAlert2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <script>
        function openModal(eventId) {
            // Set the event ID in the modal form
            document.getElementById('event').value = eventId;
            // Open the modal
            let csvModal = new bootstrap.Modal(document.getElementById('modal-file'));
            csvModal.show();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/package/laravel-speed-date/src/resources/views/speed-date/events/index.blade.php ENDPATH**/ ?>