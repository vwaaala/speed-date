<?php
    use Bunker\LaravelSpeedDate\Enums\GenderEnum;
?>

<?php $__env->startPush('scripts'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="card p-4">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-12 mb-2">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title"><?php echo e(__('global.edit')); ?> <?php echo e(__('pages.users.title_singular')); ?></h5>
                        <!-- Card title for basic information -->
                    </div>
                    <div class="card-body">
                        <!-- Form for updating users basic information -->
                        <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>"
                              enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?> <!-- Method spoofing to use PUT method -->
                            <?php echo csrf_field(); ?> <!-- CSRF protection -->

                            <div class="row">
                                <div class="col-12 mb-2">
                                    <!-- Input field for user's name -->
                                    <label for="name" class="form-label"><?php echo e(__('pages.users.fields.title')); ?> <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="name"
                                           name="name" value="<?php echo e($user->name); ?>" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <!-- Error message for name input -->
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 mb-2">
                                    <!-- Input field for user's email (disabled) -->
                                    <label for="email" class="form-label"><?php echo e(__('pages.users.fields.email')); ?></label>
                                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="email"
                                           value="<?php echo e($user->email); ?>" disabled>
                                    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.
                                    </div>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <!-- Error message for email input -->
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 mb-2">
                                    <!-- Input field for users's avatar -->
                                    <label for="avatar" class="form-label"><?php echo e(__('global.photo')); ?></label>
                                    <div class="row">
                                        <div class="col-10">
                                            <input type="file"
                                                   class="form-control image <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   id="avatar" name="avatar">
                                            <img src="" style="width: 200px;display: none;" class="show-image">
                                            <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <!-- Error message for avatar input -->
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-2">
                                            <!-- Displaying users's avatar -->
                                            <img src="<?php echo e(asset($user->avatar)); ?>" alt="Avatar" class="rounded-circle "
                                                 height="30">
                                        </div>
                                    </div>
                                </div>

                                <?php if(count($roles) >= 1): ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user_create', 'user_delete'])): ?>
                                        <div class="col-6 mb-2">
                                            <!-- Dropdown for selecting user's roles -->
                                            <label for="roleSelect"
                                                   class="form-label"><?php echo e(__('pages.users.fields.roles')); ?>

                                                <span
                                                    class="text-danger">*</span></label>
                                            <select class="form-select <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="roleSelect"
                                                    name="role">
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value); ?>"
                                                            <?php if($user->hasRole($value)): ?> selected <?php endif; ?>><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <!-- Error message for roles select -->
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-6 mb-2">
                                            <!-- Dropdown for selecting user's status -->
                                            <label for="statusSelect" class="form-label"><?php echo e(__('global.status')); ?> <span
                                                    class="text-danger">*</span></label>
                                            <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="statusSelect"
                                                    name="status">
                                                <?php $__currentLoopData = ['pending', 'active', 'inactive', 'banned']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                        $isSelected = ($user->status == $value) ? 'selected' : '';
                                                        ?>
                                                    <option
                                                        value="<?php echo e($value); ?>" <?php echo e($isSelected); ?>><?php echo e(ucfirst($value)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <!-- Error message for status select -->
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <div class="col-12 mt-2">
                                    <!-- Button to submit users update -->
                                    <button type="submit"
                                            class="btn btn-primary"><?php echo e(__('global.update')); ?> <?php echo e(__('pages.users.title_singular')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12 mb-2">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title"><?php echo e(__('global.update')); ?> <?php echo e(__('pages.users.title_singular')); ?> <?php echo e(__('pages.users.fields.password')); ?></h5>
                        <!-- Card title for updating password -->
                    </div>
                    <div class="card-body">
                        <!-- Form for updating user's password -->
                        <form method="POST" action="<?php echo e(route('users.changePassword', $user->id)); ?>">
                            <?php echo method_field('PUT'); ?> <!-- Method spoofing to use PUT method -->
                            <?php echo csrf_field(); ?> <!-- CSRF protection -->

                            <div class="mb-3">
                                <!-- Input field for new password -->
                                <label for="password" class="form-label"><?php echo e(__('pages.users.fields.password')); ?></label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>

                            <div class="mb-3">
                                <!-- Input field for confirming new password -->
                                <label for="password_confirmation"
                                       class="form-label"><?php echo e(__('pages.users.fields.password_confirm')); ?></label>
                                <input type="password" class="form-control" id="password_confirmation"
                                       name="password_confirmation"
                                       required>
                            </div>

                            <!-- Button to submit password update -->
                            <button type="submit"
                                    class="btn btn-primary"><?php echo e(__('global.update')); ?> <?php echo e(__('pages.users.fields.password')); ?></button>
                        </form>
                    </div>
                </div>
            </div>

<?php if($user->id != 1): ?>
<div class="col-lg-6 col-md-12 col-12 mb-2">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title"><?php echo e(__('global.update')); ?> Bio</h5>
            <!-- Card title for updating password -->
        </div>
        <div class="card-body">
            <!-- Form for updating user's password -->
            <form method="POST" action="<?php echo e(route('users.updatebio', $user->id)); ?>">
                <?php echo method_field('PUT'); ?> <!-- Method spoofing to use PUT method -->
                <?php echo csrf_field(); ?> <!-- CSRF protection -->
                <div class="row">
                    <div class="col-12 mb-2">
                        <!-- Input field for user's nick name -->
                        <label for="nickname" class="form-label">Nick Name</label>
                        <input type="text" class="form-control"
                               id="nickname"
                               name="nickname" value="<?php echo e($user->bio->nickname); ?>">
                    </div>
                    <div class="col-12 mb-2">
                        <!-- Input field for user's last name -->
                        <label for="lastname" class="form-label">Last Name</label>
                        <input type="text" class="form-control"
                               id="lastname"
                               name="lastname" value="<?php echo e($user->bio->lastname); ?>">
                    </div>
                    <div class="col-12 mb-2">
                        <!-- Input field for user's city -->
                        <label for="lastname" class="form-label">City</label>
                        <input type="text" class="form-control"
                               id="city"
                               name="city" value="<?php echo e($user->bio->city); ?>">
                    </div>
                    <div class="col-12 mb-2">
                        <!-- Input field for user's occupation -->
                        <label for="occupation" class="form-label">Occupation</label>
                        <input type="text" class="form-control"
                               id="occupation"
                               name="occupation" value="<?php echo e($user->bio->occupation); ?>">
                    </div>
                    <div class="col-12 mb-2">
                        <!-- Input field for user's phone -->
                        <label for="phone" class="form-label">Phone</label>
                        <input type="text" class="form-control"
                               id="phone"
                               name="phone" value="<?php echo e($user->bio->phone); ?>">
                    </div>
                    <div class="col-12 mb-2">
                        <!-- Input field for user's birthdate -->
                        <label for="birthdate" class="form-label">Birthdate</label>
                        <input type="text" class="form-control"
                               id="birthdate"
                               name="birthdate" value="<?php echo e($user->bio->birthdate); ?>">
                    </div>
                    <div class="col-6 mb-2">
                        <!-- Dropdown for selecting user's gender -->
                        <label for="gender" class="form-label">Gender <span
                                class="text-danger">*</span></label>
                        <select class="form-select"
                                id="gender"
                                name="gender">
                            <?php $__currentLoopData = GenderEnum::toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    if($value == GenderEnum::BOTH){
                                        continue;
                                    }
                                    $isSelected = ($user->bio->gender == $value) ? 'selected' : '';
                                    ?>
                                <option
                                    value="<?php echo e($value); ?>" <?php echo e($isSelected); ?>><?php echo e(ucfirst($value)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-6 mb-2">
                        <!-- Dropdown for selecting user's lookingfor -->
                        <label for="looking_for" class="form-label">Looking For <span
                                class="text-danger">*</span></label>
                        <select class="form-select"
                                id="looking_for"
                                name="looking_for">
                            <?php $__currentLoopData = GenderEnum::toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $isSelected = ($user->bio->looking_for == $value) ? 'selected' : '';
                                    ?>
                                <option
                                    value="<?php echo e($value); ?>" <?php echo e($isSelected); ?>><?php echo e(ucfirst($value)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <!-- Button to submit password update -->
                <button type="submit"
                        class="btn btn-primary"><?php echo e(__('global.update')); ?> Bio</button>
            </form>
        </div>
    </div>
</div>

<?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
    $('#birthdate').datepicker({
        format: 'yyyy/mm/dd',
        autoclose: true
    });
});

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/resources/views/pages/users/edit.blade.php ENDPATH**/ ?>