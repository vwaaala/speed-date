<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><?php echo e(__('global.profile')); ?></span>
                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning"><span
                        class="bi bi-pencil"></span> </a>
            </div>
        </div>

        <div class="card-body">
            <div class="row">
                <!-- Profile Photo -->
                <div class="col-md-3 d-flex align-items-center justify-content-center">
                    <img src="<?php echo e(asset($user->avatar)); ?>" class="img-fluid rounded" style="height:200px" alt="Your Profile Photo">
                </div>

                <!-- Name and Email -->
                <div class="col-md-9">
                    <!-- Full Name -->
                    <h3><?php echo e($user->name); ?></h3>

                    <!-- Email with Mail Icon -->
                    <p><strong><i class="bi bi-envelope-check"></i></strong> <?php echo e($user->email); ?></p>
                    <!-- Bio -->
                    <?php if($user->bio): ?>
                        <p><strong>Bio:</strong> <?php echo e($user->bio->nickname); ?> - <?php echo e($user->bio->city); ?> - <?php echo e($user->bio->occupation); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($user->bio->phone); ?></p>
                        <p><strong>Birthdate:</strong> <?php echo e($user->bio->birthdate); ?></p>
                        <p><strong>Gender:</strong> <?php echo e($user->bio->gender); ?></p>
                        <p><strong>Looking For:</strong> <?php echo e($user->bio->looking_for); ?></p>
                    <?php else: ?>
                        <p><strong>Bio:</strong> No bio available.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageName' => config('pages.users.show')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/resources/views/pages/users/view.blade.php ENDPATH**/ ?>