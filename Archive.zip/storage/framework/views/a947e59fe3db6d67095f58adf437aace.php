<?php if(!request()->routeIs('dashboard')): ?>
    <?php
        $breadCrumbs = [];
        $currentRoute = request()->route()->getName();
        foreach(config('pages') as $page){
            if($page['href'] == $currentRoute){
                $breadCrumbs[] = ['href' => $page['href'], 'text' => $page['text']];
            }else{
                foreach($page['children'] as $child){
                    if($child['href'] == $currentRoute){
                        $breadCrumbs[] = ['href' => $page['href'], 'text' => $page['text']];
                        $breadCrumbs[] = ['href' => $child['href'], 'text' => $child['text']];
                    }
                }
            }
        }
    ?>
    <div class="d-flex mb-2 justify-content-between">
        <button onclick="window.history.back();" class="btn btn-sm btn-outline-primary"><span
                class="bi bi-arrow-return-left"></span>
            <?php echo e(__('global.back_to_list')); ?>

        </button>
        <?php if(isset($breadCrumbs)): ?>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route(config('pages')[0]['href'])); ?>"><?php echo e(__(config('pages')[0]['text'])); ?></a>
                    </li>
                    <?php $__currentLoopData = $breadCrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!request()->routeIs($bread['href'])): ?>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route($bread['href'])); ?>"><?php echo e(__($bread['text'])); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__($bread['text'])); ?></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </nav>
        <?php endif; ?>

    </div>
<?php endif; ?>
<?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/resources/views/layouts/partials/breadcrumb.blade.php ENDPATH**/ ?>