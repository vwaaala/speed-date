<div class="btn-group">
    <?php if(Route::currentRouteName() == 'users.index' && !request()->has('show_deleted')): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_show')): ?>
            <a href="<?php echo e(route('users.show', $id ?? $user->id)); ?>" class="btn btn-sm btn-primary" title="<?php echo e(__('global.show')); ?>">
                <span class="bi bi-eye"></span> <!-- Bootstrap eye icon -->
            </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_edit')): ?>
            <a href="<?php echo e(route('users.edit', $id ?? $user->id)); ?>" class="btn btn-sm btn-warning" title="<?php echo e(__('global.edit')); ?>">
                <span class="bi bi-pencil"></span> <!-- Bootstrap pencil icon -->
            </a>
        <?php endif; ?>
    <?php else: ?>
        <!-- Display "Retrieve" button if show_deleted parameter is set -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_delete')): ?>
            <a href="<?php echo e(route('users.retrieveDeleted', $id ?? $user->id)); ?>" class="btn btn-sm btn-success"
               title="<?php echo e(__('global.restore')); ?>">
                <span class="bi bi-arrow-return-left"></span> <!-- Bootstrap arrow-return-left icon -->
            </a>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_delete')): ?>
        <a onclick="confirmDelete('<?php echo e(request()->has('show_deleted') ? route('users.forceDelete', $id) : route('users.destroy', $id)); ?>')" href="#" class="btn btn-sm btn-danger"
           title="<?php echo e(__('global.delete')); ?>">
            <span class="bi bi-trash"></span> <!-- Bootstrap arrow-return-left icon -->
        </a>
    <?php endif; ?>
</div><?php /**PATH /Users/mehrabahmedsaurav/Desktop/laraproj/speed-date/resources/views/pages/users/action.blade.php ENDPATH**/ ?>