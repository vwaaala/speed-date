import './bootstrap';
import 'laravel-datatables-vite';

// datepicker
import 'bootstrap-datepicker';

import './main.js';


