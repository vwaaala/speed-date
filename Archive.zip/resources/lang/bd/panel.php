<?php

return [
    'site_title' => 'বাংকার',
];
