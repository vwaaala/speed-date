<?php

return [
    'previous' => '&laquo; আগে',
    'next'     => 'পরবর্তী &raquo;',
];
