<?php

return [
    'site_title' => 'Bunker',
];
