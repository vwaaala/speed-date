<?php

return [
    'events' => 'ডেটিং ইভেন্ট',
    'votes' => 'ভোট',
];
