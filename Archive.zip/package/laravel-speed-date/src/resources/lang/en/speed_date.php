<?php

return [
    'events' => 'Events',
    'votes' => 'Votes'
];
